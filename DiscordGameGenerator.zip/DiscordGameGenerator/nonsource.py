import random
import tkinter as tk

def set_window_title():
    words = ['Shit', 'Food', 'Car', 'Space', 'Pet', 'Plant', 'House', 'Money', 'Weather', 'Music']
    title = random.choice(words) + " " + random.choice(["Simulator", "Tycoon", ""]) + " " + str(random.randint(2000, 2023))
    root = tk.Tk()
    root.title(title)
    root.configure(bg='#7289DA')

    label = tk.Label(root, text="The Game is running!", font=("Helvetica", 20, "bold"), bg='#7289DA', fg='white')
    label.pack(pady=30)

    sublabel = tk.Label(root, text="It should show on Discord.", font=("Helvetica", 12), bg='#7289DA', fg='white')
    sublabel.pack()

    root.mainloop()

if __name__ == '__main__':
    set_window_title()
